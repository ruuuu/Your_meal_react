## Сервер YOUR_MEAL.


Вы можете использовать его по адресу http://localhost:3024


Доступные методы:


GET /api/product - получить список товаров

GET /api/product?category={category} - получить список товаров по категории

GET /api/product/category - получить список категорий

GET /api/product/{id} - получить товар по его ID

GET /api/product?list={id,id,id} - получить список с id);
